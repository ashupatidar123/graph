referance link
https://developers.google.com/chart/interactive/docs/gallery/combochart


=======================dashborad view page in CI=============
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<?php if(!empty($monthly_Data)):?>
	<script type="text/javascript">
	    google.charts.load('current', {'packages':['corechart']});
	    google.charts.setOnLoadCallback(drawChart);

	    function drawChart() {
	        var data = google.visualization.arrayToDataTable(<?php echo json_encode($monthly_Data); ?>);

	        var options = {
	       	  selectionMode: 'multiple',	 	
	          title : 'Monthly Report',
	          vAxis: {title: 'Max Cases'},
	          // hAxis: {title: 'Date'},
	          seriesType: 'bars',
	          
	        };

	        var chart = new google.visualization.ComboChart(document.getElementById('monthly_Data'));
	        chart.draw(data, options);
	    }
	</script>
<?php endif;?>



=====================Controller==============================
<?php


public function monthlyGraph(){
    $whereAns = "WHERE (date(crd) >= DATE(NOW()) - INTERVAL 31 DAY) AND question=1 AND isDeleted='NO' GROUP BY date(crd)";
    $order = "ORDER BY crd ASC";
    $limit = "LIMIT 0,31";
    $a_data = $this->common_model->customFetch('answerId,answer,crd','userAnswer',$whereAns,$order,$limit);

    $monthly_Data = array();
    foreach($a_data as $key=>$a_row){
        $answerId = $a_row['answerId'];
        $answer   = $a_row['answer'];
        $crd      = date('Y-m-d',strtotime($a_row['crd'])); 

        $whereNgt = "(answer=1 OR answer=2) AND question=1 AND date(crd)='$crd'";
        $negative_count = $this->common_model->countQuery('userAnswer',$whereNgt);
        ;

        $wherePos = "(answer=3 OR answer=4) AND question=1 AND date(crd)='$crd'";
        $posative_count = $this->common_model->countQuery('userAnswer',$wherePos);
        ;

        if($key==0){
            $monthly_Data[] = array(
                '0'=>'Date',
                '1'=>'Negative',
                '2'=>'Positive'
            );
        }
        $monthly_Data[] = array(
            '0'=>date('d/M/y',strtotime($a_row['crd'])),
            '1'=>(int)$negative_count,
            '2'=>(int)$posative_count
        );
    }
    //pd($monthly_Data);
    return $monthly_Data;
}

?>
https://canvasjs.com/php-charts/candlestick-chart/

dashboard.php page call
<body onload="pieChart()">

trial version remove in canvas
fTx:"ghmmUdyu"  

remove ghmmUdyu

<!-- Show grap position -->

<div id="chartContainer" style="height: 370px; width: 100%;"></div>

<?php

$dataPoints = array( 
  array("label"=>"Uncompleted Tasks", "y"=>$Uncompleted),
  array("label"=>"New Unassign Tasks", "y"=>$Unassign),
  array("label"=>"Completed Tasks", "y"=>$Completed),
  array("label"=>"Overdue Tasks", "y"=>$Overdue),
  array("label"=>"All Tasks", "y"=>$Overdue)
)
 
?>
<!-- <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script> -->

<script src="<?=base_url('assets/admin/js/canvasjs.min.js');?>"></script>
<script>
      function pieChart()
      {
        var chart = new CanvasJS.Chart("chartContainer", {
          theme: "light2",
          animationEnabled: true,
          // title: {
          //   text: "Over All Tasks and Users"
          // },
          data: [{
            type: "pie",
            indexLabel: "{y}",
            yValueFormatString: "#,##0.00\"%\"",
            indexLabelPlacement: "inside",
            indexLabelFontColor: "#36454F",
            indexLabelFontSize: 18,
            indexLabelFontWeight: "bolder",
            showInLegend: true,
            legendText: "{label}",
            dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
          }]
        });
        chart.render();       
      }
      
  </script>